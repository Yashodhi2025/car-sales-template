import fs from "node:fs";

// Keep Fivora's controls aligned with the actual, source-backed template data.
// This does not initialize Deneb or alter its configuration/integrations.
const data = JSON.parse(fs.readFileSync("src/data/site-data.json", "utf8").replace(/^\uFEFF/, ""));
const manifest = JSON.parse(fs.readFileSync("fivora-template.json", "utf8").replace(/^\uFEFF/, ""));
const label = key => key.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[-_.]/g, " ").replace(/^./, char => char.toUpperCase());
const controls = new Set();

function fields(object, prefix) {
  return Object.entries(object).map(([key, value]) => {
    const path = `${prefix}.${key}`;
    if (/^inventory\.filters\.(showLabel|hideLabel)$/.test(path)) controls.add(path);
    if (path === "common.currencyCode") controls.add(path);
    if (path.startsWith("loanCalculator.defaults.") || path === "loanCalculator.noScript") controls.add(path);
    if (path.startsWith("common.actionPalette.")) controls.add(path);
    if (/^inventory\.showcase\.(label|selectLabel)$/.test(path)) controls.add(path);
    if (/^inventory\.showcase\.featured\.[^.]+\.(enabled|order)$/.test(path) || /^inventory\.showcase\.empty(Title|Description)$/.test(path)) controls.add(path);
    if (Array.isArray(value)) {
      const itemFields = value.map((item, index) => fields(item, `${path}.${index}`));
      return { key, type: "list", label: label(key), fields: itemFields[0] || [] };
    }
    if (value && typeof value === "object") return { key, type: "object", label: label(key), fields: fields(value, path) };
    let type = "text";
    if (typeof value === "number") type = "number";
    else if (typeof value === "boolean") type = "boolean";
    else if (/^(image\d*|imageUrl|logoUrl)$|Image$/.test(key)) type = "image";
    else if (/Link$/.test(key) || prefix === "common.navLinks") type = "url";
    else if (/email$/i.test(key) && !prefix.endsWith(".errors")) type = "email";
    else if (/^(phone|whatsapp)$/i.test(key) && !prefix.endsWith(".errors")) type = "tel";
    else if (/description|quote|text|shortDescription|demoNotice|answer/i.test(key)) type = "textarea";
    if (/^home\.search\.(eyebrow|title|description|resetLabel)$/.test(path)) controls.add(path);
    if (/^cards\.brands\.[^.]+\.countLabel$/.test(path) || path === "common.searchPlaceholder" || path === "common.searchLabel" || path.startsWith("catalog.") || /imageAlt$|previousLabel$|nextLabel$|allBrands$|allBodies$/i.test(path)
      || /^inventory\.filters\.(any\w+|availableLabel|reservedLabel|removeLabel|minPlaceholder|maxPlaceholder)$/.test(path)
      || /^inventory\.results\.(sort(?!Label)\w+|noScript)$/.test(path)) controls.add(path);
    if (/^vehicleDetails\.gallery\.(previousLabel|nextLabel|closeLabel|thumbnailLabel|openImageLabel)$/.test(path) || path === "vehicleDetails.notSupplied") controls.add(path);
    if (/^vehicleDetails\.navigation\.(label|enquiry)$/.test(path)) controls.add(path);
    if (/^requests\.(fields\.[^.]+\.placeholder|types\.|contactSubject$|viewingSubject$|noVehicle$|draftTextLabel$|noScript$)/.test(path) || path === "viewing.messagePlaceholder" || path.startsWith("motion.")) controls.add(path);
    if (/^home\.testimonials\.(carouselLabel|storyLabel)$/.test(path) || /^services\.items\.\d+\.targetPage$/.test(path)) controls.add(path);
    const fieldLabel = path.startsWith("inventory.showcase.featured.") && key === "enabled" ? "Show in showcase" : path.startsWith("inventory.showcase.featured.") && key === "order" ? "Display order" : label(key);
    return { key, type, label: fieldLabel, ...(key === "icon" || prefix === "vehicleDetails.specIcons" ? { control: "icon-picker" } : {}) };
  });
}
function owner(path) {
  if(path.startsWith("services")) return "services";
  if(path.startsWith("faq")) return "contact";
  const vehicle = path.match(/^(?:vehicles|photos\.vehicles)\.([^.]+)/)?.[1];
  if (vehicle && Object.hasOwn(data.content.vehicles, vehicle)) return `car-${vehicle}`;
  if (path === "vehicleDetails") return `car-${Object.keys(data.content.vehicles)[0]}`;
  if (path === "loanCalculator") return `car-${Object.keys(data.content.vehicles)[0]}`;
  if (/^viewing|^requests\.fields\.(date|time)/.test(path)) return `car-${Object.keys(data.content.vehicles)[0]}`;
  if (path.startsWith("requests")) return "contact";
  if (/^(inventory|catalog|photos\.vehicles|cards\.vehicles)/.test(path) || path === "home.collection.emptyTitle" || path === "home.collection.emptyDescription") return "inventory";
  if (/^about|^home\.(promise|benefits|experience)/.test(path)) return "about";
  if (/^contact|^showrooms|^home\.contact/.test(path)) return "contact";
  return "home";
}
function objectSection(path, value) {
  return { id: path, path, type: "object", label: label(path), fields: fields(value, path), ...(path === "common" ? {} : { pageKey: owner(path) }) };
}
function collection(path, value) {
  if (!Array.isArray(value)) return objectSection(path, value);
  const itemFields = value.map((item, index) => fields(item, `${path}.${index}`));
  return { id: path, path, type: "list", label: label(path), pageKey: owner(path), fields: itemFields[0] || [] };
}
const intake = manifest.editorSchema.sections.find(section => section.id === "__fivoraIntake");
const sections = [objectSection("common", data.content.common)];
for (const [key, value] of Object.entries(data.content.home)) {
  sections.push(Array.isArray(value) ? collection(`home.${key}`, value) : objectSection(`home.${key}`, value));
}
for (const [key, value] of Object.entries(data.content.inventory)) sections.push(objectSection(`inventory.${key}`, value));
const { journey, ...about } = data.content.about;
sections.push(objectSection("about", about), collection("about.journey", journey), objectSection("contact", data.content.contact));
for(const key of ["services","faq"]){
  const {items,trustFeatures,steps,...copy}=data.content[key];
  sections.push(objectSection(key,copy),collection(`${key}.items`,items));
  if(trustFeatures) sections.push(collection(`${key}.trustFeatures`,trustFeatures));
  if(steps) sections.push(collection(`${key}.steps`,steps));
}
const { fields: requestFields, types, errors, ...requestCopy } = data.content.requests;
const { date: dateError, pastDate, time: timeError, ...sharedErrors } = errors;
sections.push(objectSection("requests", { ...requestCopy, errors: sharedErrors }), collection("requests.types", types));
for (const [key, value] of Object.entries(requestFields)) sections.push(objectSection(`requests.fields.${key}`, value));
sections.push({ ...objectSection("requests.errors", { date: dateError, pastDate, time: timeError }), id: "viewing.errors", pageKey: `car-${Object.keys(data.content.vehicles)[0]}` }, objectSection("viewing", data.content.viewing), objectSection("motion", data.content.motion));
for (const [key, value] of Object.entries(data.content.cards)) sections.push(collection(`cards.${key}`, value));
const { bodyStyles, ...vehicleDetails } = data.content.vehicleDetails;
sections.push(collection("catalog", data.content.catalog), collection("showrooms", data.content.showrooms), objectSection("vehicleDetails", vehicleDetails));
sections.push({ id: "vehicleDetails.bodyStyles", path: "vehicleDetails.bodyStyles", type: "object", label: "Shared body style labels", fields: fields(bodyStyles, "vehicleDetails.bodyStyles") });
sections.push({ ...objectSection("loanCalculator", data.content.loanCalculator), label: "Loan / EMI Calculator", description: "Shared across all car details pages. Vehicle price comes from each vehicle's editable card price; currency uses Common / Currency code. Defaults set the initial down payment percentage, annual interest rate and term in months. Visitors can adjust all four inputs." });
for (const [id, vehicle] of Object.entries(data.content.vehicles)) {
  const { features, ...details } = vehicle;
  const { gallery, showcaseImage, ...photos } = data.content.photos.vehicles[id];
  sections.push(objectSection(`vehicles.${id}`, details), collection(`vehicles.${id}.features`, features), objectSection(`photos.vehicles.${id}`, photos), collection(`photos.vehicles.${id}.gallery`, gallery));
  controls.add(`photos.vehicles.${id}.showcaseImage`);
  sections.push({ id: `inventory.showcase.${id}`, path: `photos.vehicles.${id}.showcaseImage`, type: "image", label: `Inventory showcase photo / ${data.content.cards.vehicles[id].name}`, pageKey: "inventory", description: "Upload a transparent side-view PNG/WebP, facing right. Enable this car under Inventory showcase / Featured and set its display order. Only enabled cars with a showcase image appear in the scene; the stock gallery is separate.", recommendedWidth: 2000, recommendedHeight: 750 });
}
if (intake) sections.push(intake);
manifest.name = "Vanguard Motors";
manifest.pages = [
  { id: "home", label: "Home", route: "/", required: true },
  { id: "inventory", label: "Inventory", route: "/inventory", required: true },
  { id: "services", label: "Services", route: "/services", required: true },
  { id: "about", label: "About", route: "/about", required: true },
  { id: "contact", label: "Contact", route: "/contact", required: true },
  ...Object.keys(data.content.vehicles).map(id => ({ id: `car-${id}`, label: data.content.cards.vehicles[id].name, route: `/cars/${id}`, required: true })),
];
manifest.editorSchema.sections = sections;
function canonicalControl(path) {
  let value = data.content; let result = "";
  for (const key of path.split(".")) {
    result += Array.isArray(value) && /^\d+$/.test(key) ? `[${key}]` : `${result ? "." : ""}${key}`;
    value = value && typeof value === "object" ? value[key] : undefined;
  }
  return result;
}
manifest.visualEditing = { ...manifest.visualEditing, contractVersion: 1, mode: "strict", controlOnlyPaths: [...new Set([...(manifest.visualEditing.controlOnlyPaths || []).filter(path => path.startsWith("__fivoraIntake.")), ...controls])].map(canonicalControl).map(path => path.replace(/\[\d+\]/g, "[*]")).filter((path, index, paths) => paths.indexOf(path) === index).sort() };
fs.writeFileSync("fivora-template.json", `${JSON.stringify(manifest, null, 2)}\n`);
console.log(`Synced ${sections.length} editor sections; ${controls.size} explicit control-only fields.`);
